package modele;

public class Nourriture {

}
